#!/bin/sh
echo 'VERSION="'$(cat VERSION.txt)'"' > version.py
